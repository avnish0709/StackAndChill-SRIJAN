import {
  AlertCircle,
  ArrowUpRight,
  Check,
  ChevronDown,
  CircleHelp,
  ClipboardCheck,
  File,
  FileArchive,
  FileCheck2,
  FileText,
  FolderOpen,
  Image as ImageIcon,
  Info,
  LayoutGrid,
  MessageCircle,
  Paperclip,
  Plus,
  RotateCcw,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  UploadCloud,
  X,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const markUrl = "/manus-storage/legal-first-aid-mark_3c9d70cf.png";
const clauseImageUrl = "/manus-storage/legal-clause-detail_91a1f7b9.jpg";

type ToolKey = "files" | "photos" | "documents";
type EvidenceStatus = "Supported" | "Partly supported" | "Insufficient";

type ChatMessage = {
  role: "assistant" | "user";
  text: string;
};

const toolItems: Array<{
  key: ToolKey;
  label: string;
  helper: string;
  icon: typeof File;
  tone: string;
}> = [
  {
    key: "files",
    label: "Files",
    helper: "Browse case materials",
    icon: FolderOpen,
    tone: "tool-card--navy",
  },
  {
    key: "photos",
    label: "Photos",
    helper: "Add images or scans",
    icon: ImageIcon,
    tone: "tool-card--clay",
  },
  {
    key: "documents",
    label: "Documents",
    helper: "Organise source PDFs",
    icon: FileText,
    tone: "tool-card--saffron",
  },
];

const evidenceRows: Array<{
  title: string;
  detail: string;
  status: EvidenceStatus;
  icon: typeof Check;
}> = [
  {
    title: "Early termination clause",
    detail: "Section 8 · Page 4 of 12",
    status: "Supported",
    icon: Check,
  },
  {
    title: "Notice period",
    detail: "Referenced in Section 8.2",
    status: "Partly supported",
    icon: AlertCircle,
  },
  {
    title: "Local tenancy rules",
    detail: "No jurisdiction supplied yet",
    status: "Insufficient",
    icon: Info,
  },
];

function statusClasses(status: EvidenceStatus) {
  if (status === "Supported") return "evidence-pill evidence-pill--supported";
  if (status === "Partly supported") return "evidence-pill evidence-pill--partial";
  return "evidence-pill evidence-pill--insufficient";
}

function Logo() {
  return (
    <div className="brand-lockup" aria-label="Legal First-Aid AI">
      <img className="brand-mark" src={markUrl} alt="" />
      <div>
        <p className="brand-name">LEGAL FIRST-AID <span>AI</span></p>
        <p className="brand-subtitle">Evidence before advice</p>
      </div>
    </div>
  );
}

function Header({ onHelp }: { onHelp: () => void }) {
  return (
    <header className="app-header">
      <Logo />
      <nav className="top-nav" aria-label="Primary navigation">
        <a className="top-nav__link top-nav__link--active" href="#workspace">Workspace</a>
        <a className="top-nav__link" href="#how-it-works">How it works</a>
        <a className="top-nav__link" href="#responsible-use">Responsible use</a>
      </nav>
      <div className="header-actions">
        <button className="icon-button" type="button" aria-label="Search" onClick={() => toast("Search will be connected to your case library later.")}>
          <Search size={17} strokeWidth={1.8} />
        </button>
        <button className="help-button" type="button" onClick={onHelp}>
          <CircleHelp size={16} />
          <span>Need help?</span>
        </button>
        <div className="avatar" aria-label="Demo user">AR</div>
      </div>
    </header>
  );
}

function SideRail() {
  return (
    <aside className="left-rail" aria-label="Workspace navigation">
      <div className="rail-kicker">Your workspace</div>
      <div className="rail-nav">
        <a className="rail-nav__item rail-nav__item--active" href="#workspace">
          <LayoutGrid size={17} />
          <span>Overview</span>
        </a>
        <a className="rail-nav__item" href="#case-file" onClick={() => toast("Case file view is a frontend placeholder.")}>
          <FileCheck2 size={17} />
          <span>Case file</span>
        </a>
        <a className="rail-nav__item" href="#evidence" onClick={() => toast("Evidence index is visible in this prototype below.")}>
          <ClipboardCheck size={17} />
          <span>Evidence index</span>
        </a>
      </div>
      <div className="rail-divider" />
      <div className="rail-caption">
        <ShieldCheck size={18} />
        <div>
          <strong>Private by design</strong>
          <span>This demo keeps your inputs local.</span>
        </div>
      </div>
      <div className="rail-bottom">
        <span className="status-dot" />
        <span>Prototype mode</span>
      </div>
    </aside>
  );
}

function ActionRail({ activeTool, onSelect }: { activeTool: ToolKey; onSelect: (key: ToolKey) => void }) {
  return (
    <aside className="action-rail" aria-label="File and media actions">
      <div className="action-rail__heading">
        <div>
          <p className="section-label">Quick tools</p>
          <h2>Bring in what matters.</h2>
        </div>
        <span className="utility-count">03</span>
      </div>
      <p className="action-rail__intro">Keep documents, photos, and supporting files close to the question you are asking.</p>
      <div className="tool-stack">
        {toolItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = activeTool === item.key;
          return (
            <button
              key={item.key}
              type="button"
              className={`tool-card ${item.tone} ${isActive ? "tool-card--active" : ""}`}
              onClick={() => onSelect(item.key)}
              style={{ "--tool-delay": `${index * 45}ms` } as React.CSSProperties}
            >
              <span className="tool-card__icon"><Icon size={19} strokeWidth={1.7} /></span>
              <span className="tool-card__copy"><strong>{item.label}</strong><small>{item.helper}</small></span>
              <ArrowUpRight className="tool-card__arrow" size={16} />
            </button>
          );
        })}
      </div>
      <div className="action-rail__note">
        <Paperclip size={16} />
        <span>Supported: PDF, JPG, PNG, DOCX</span>
      </div>
      <div className="case-summary">
        <div className="case-summary__top"><span>Current case</span><span className="case-summary__status">Draft</span></div>
        <strong>Rental agreement</strong>
        <span>Last touched just now</span>
      </div>
    </aside>
  );
}

function UploadCard({ onFile }: { onFile: (file: File) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [uploaded, setUploaded] = useState(false);

  const acceptFile = (file?: File) => {
    if (!file) return;
    setUploaded(true);
    onFile(file);
    toast.success(`${file.name} added to this case.`);
  };

  return (
    <section className="surface-card upload-card" aria-labelledby="upload-title">
      <div className="card-heading-row">
        <div>
          <p className="section-label">Step 01 · Source</p>
          <h2 id="upload-title">Add a document to begin.</h2>
        </div>
        <div className="step-marker">1 / 3</div>
      </div>
      <p className="card-lead">Start with the file that contains the facts. We will not imply it has been analysed until you ask us to.</p>
      {!uploaded ? (
        <button
          type="button"
          className={`dropzone ${dragging ? "dropzone--dragging" : ""}`}
          onClick={() => inputRef.current?.click()}
          onDragEnter={(event) => { event.preventDefault(); setDragging(true); }}
          onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(event) => { event.preventDefault(); setDragging(false); acceptFile(event.dataTransfer.files?.[0]); }}
        >
          <span className="dropzone__icon"><UploadCloud size={23} strokeWidth={1.6} /></span>
          <strong>{dragging ? "Release to add this file" : "Drop a document here"}</strong>
          <span>PDF, DOCX, or a clear photo · up to 20 MB</span>
          <span className="dropzone__button">Choose file <ArrowUpRight size={14} /></span>
          <input ref={inputRef} hidden type="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" onChange={(event) => acceptFile(event.target.files?.[0])} />
        </button>
      ) : (
        <div className="uploaded-file">
          <div className="uploaded-file__icon"><FileArchive size={21} /></div>
          <div className="uploaded-file__copy"><strong>Rental_Agreement.pdf</strong><span>PDF · 1.8 MB · Added just now</span></div>
          <span className="uploaded-file__state"><Check size={14} /> Ready</span>
          <button className="icon-button icon-button--small" type="button" aria-label="Remove file" onClick={() => setUploaded(false)}><X size={15} /></button>
        </div>
      )}
      <div className="upload-card__footer"><span><ShieldCheck size={14} /> Files stay in this prototype session.</span><button type="button" onClick={() => toast("Replace will open the file picker in the connected version.")}>Replace file</button></div>
    </section>
  );
}

function QuestionCard({ action, setAction, onAnalyze, analyzing }: { action: string; setAction: (value: string) => void; onAnalyze: () => void; analyzing: boolean }) {
  const suggestions = ["Terminate an agreement", "Understand a penalty", "Check a notice requirement", "Review a clause"];
  return (
    <section className="surface-card question-card" aria-labelledby="question-title">
      <div className="card-heading-row">
        <div>
          <p className="section-label">Step 02 · Intention</p>
          <h2 id="question-title">What are you trying to do?</h2>
        </div>
        <div className="step-marker">2 / 3</div>
      </div>
      <p className="card-lead">The clearer the intended action, the more useful the analysis can be.</p>
      <textarea
        className="action-textarea"
        value={action}
        onChange={(event) => setAction(event.target.value)}
        placeholder="I want to terminate my rental agreement two months early."
        aria-label="Describe the action you want to take"
      />
      <div className="suggestion-row" aria-label="Suggested actions">
        {suggestions.map((suggestion) => <button key={suggestion} type="button" className="suggestion-chip" onClick={() => setAction(suggestion)}>{suggestion}</button>)}
      </div>
      <div className="question-card__footer">
        <span className="privacy-note"><Info size={14} /> This is an information aid, not legal advice.</span>
        <button type="button" className="primary-button" onClick={onAnalyze} disabled={analyzing || !action.trim()}>
          {analyzing ? <><span className="button-pulse" /> Reading the brief…</> : <>Analyze my document <ArrowUpRight size={16} /></>}
        </button>
      </div>
    </section>
  );
}

function EvidenceIndex({ visible }: { visible: boolean }) {
  return (
    <section className={`surface-card evidence-card ${visible ? "evidence-card--visible" : ""}`} id="evidence" aria-labelledby="evidence-title">
      <div className="card-heading-row evidence-heading">
        <div>
          <p className="section-label">Step 03 · Evidence</p>
          <h2 id="evidence-title">A first reading of what matters.</h2>
        </div>
        <span className="evidence-ribbon"><Sparkles size={14} /> Prototype result</span>
      </div>
      <div className="analysis-summary">
        <div className="analysis-summary__copy"><span className="eyebrow">Detected action</span><strong>Terminate rental agreement early</strong><p>The agreement appears to allow early termination, but conditions and notice timing need checking.</p></div>
        <div className="analysis-summary__image"><img src={clauseImageUrl} alt="Close view of a highlighted legal clause" /><span>Section 8 · Page 4</span></div>
      </div>
      <div className="evidence-list">
        {evidenceRows.map((row) => { const Icon = row.icon; return <div className="evidence-row" key={row.title}><span className={`evidence-status-icon ${row.status === "Supported" ? "is-supported" : row.status === "Partly supported" ? "is-partial" : "is-insufficient"}`}><Icon size={14} /></span><div className="evidence-row__copy"><strong>{row.title}</strong><span>{row.detail}</span></div><span className={statusClasses(row.status)}>{row.status}</span></div>; })}
      </div>
      <div className="uncertainty-callout"><AlertCircle size={18} /><div><strong>What is still missing</strong><span>Jurisdiction, exact move-out date, and whether notice has already been sent.</span></div><button type="button" onClick={() => toast("Missing information prompts are ready for the connected analysis flow.")}>Add details <ArrowUpRight size={14} /></button></div>
    </section>
  );
}

function ChatBot({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "assistant", text: "Hi. I can help you get unstuck with this workspace." },
    { role: "assistant", text: "What is the issue? Choose a quick topic or tell me in your own words." },
  ]);
  const [draft, setDraft] = useState("");
  const quickTopics = ["Upload is not working", "I do not understand the result", "Something looks wrong"];

  const send = (text = draft) => {
    const clean = text.trim();
    if (!clean) return;
    setMessages((current) => [...current, { role: "user", text: clean }, { role: "assistant", text: "Thanks — I have noted that. In the connected version, this would route to the support queue." }]);
    setDraft("");
  };

  if (!open) return null;
  return <div className="chat-panel" role="dialog" aria-label="Support chat">
    <div className="chat-panel__header"><div className="chat-agent"><span className="chat-agent__avatar"><MessageCircle size={16} /></span><div><strong>Casework support</strong><span><i /> Usually replies quickly</span></div></div><button type="button" className="icon-button icon-button--small" aria-label="Close support chat" onClick={onClose}><X size={16} /></button></div>
    <div className="chat-panel__body">
      {messages.map((message, index) => <div className={`chat-message chat-message--${message.role}`} key={`${message.role}-${index}`}><span>{message.text}</span></div>)}
      {messages.length <= 2 && <div className="chat-quick-actions">{quickTopics.map((topic) => <button key={topic} type="button" onClick={() => send(topic)}>{topic}<ArrowUpRight size={13} /></button>)}</div>}
    </div>
    <div className="chat-panel__composer"><input value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") send(); }} placeholder="Describe the issue…" aria-label="Describe your issue" /><button type="button" aria-label="Send message" onClick={() => send()}><Send size={16} /></button></div>
  </div>;
}

export default function Home() {
  const [activeTool, setActiveTool] = useState<ToolKey>("files");
  const [action, setAction] = useState("I want to terminate my rental agreement two months early.");
  const [analyzing, setAnalyzing] = useState(false);
  const [hasAnalysis, setHasAnalysis] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  const activeToolLabel = useMemo(() => toolItems.find((item) => item.key === activeTool)?.label ?? "Files", [activeTool]);

  const runAnalysis = () => {
    setAnalyzing(true);
    window.setTimeout(() => {
      setAnalyzing(false);
      setHasAnalysis(true);
      toast.success("A first reading is ready. Check the evidence status below.");
    }, 900);
  };

  const handleToolSelect = (key: ToolKey) => {
    setActiveTool(key);
    toast(`${toolItems.find((item) => item.key === key)?.label} tools selected.`);
  };

  return <div className="app-shell" id="workspace">
    <Header onHelp={() => setChatOpen(true)} />
    <div className="workspace-layout">
      <SideRail />
      <main className="main-canvas">
        <div className="workspace-intro">
          <div>
            <div className="breadcrumb"><span>Workspace</span><ChevronDown size={13} /><strong>My document</strong></div>
            <h1>Understand the document.<br /><em>Choose your next move.</em></h1>
            <p>Upload a legal document and tell us what you want to do. We will focus the reading around your intended action—not just summarize the page.</p>
          </div>
          <div className="intro-stamp"><span className="intro-stamp__line" /><span>Evidence-first<br />legal assistance</span></div>
        </div>
        <div className="mobile-tool-strip"><span className="mobile-tool-strip__label">Tools</span>{toolItems.map((item) => <button key={item.key} className={activeTool === item.key ? "is-active" : ""} type="button" onClick={() => handleToolSelect(item.key)}>{item.label}</button>)}</div>
        <div className="canvas-grid">
          <div className="flow-column">
            <UploadCard onFile={() => {}} />
            <QuestionCard action={action} setAction={setAction} onAnalyze={runAnalysis} analyzing={analyzing} />
            {hasAnalysis ? <EvidenceIndex visible={hasAnalysis} /> : <div className="evidence-preview" id="how-it-works"><div className="evidence-preview__icon"><Sparkles size={19} /></div><div><strong>Your evidence index will appear here.</strong><span>We will separate what the document supports from what still needs context.</span></div><span className="preview-dash" /></div>}
          </div>
          <div className="context-column">
            <div className="context-card">
              <div className="context-card__top"><span className="section-label">Active utility</span><span className="active-tool-mark"><i /> {activeToolLabel}</span></div>
              <h3>Make the source easier to work with.</h3>
              <p>Use the right rail to bring supporting material into the case without losing sight of your question.</p>
              <div className="context-card__list"><div><Check size={14} /><span>Trace every insight back to a source</span></div><div><Check size={14} /><span>Keep uncertain points visibly marked</span></div></div>
              <button className="secondary-button" type="button" onClick={() => toast("A guided case setup will be available once the backend is connected.")}>Open guided setup <ArrowUpRight size={15} /></button>
            </div>
            <div className="mini-disclaimer" id="responsible-use"><Info size={15} /><span><strong>Responsible use.</strong> This prototype provides general information and document reading support. It does not replace a qualified lawyer.</span></div>
          </div>
        </div>
      </main>
      <ActionRail activeTool={activeTool} onSelect={handleToolSelect} />
    </div>
    <button className={`chat-launcher ${chatOpen ? "chat-launcher--hidden" : ""}`} type="button" onClick={() => setChatOpen(true)} aria-label="Open support chat"><MessageCircle size={20} /><span>Something not working?</span><i /></button>
    <ChatBot open={chatOpen} onClose={() => setChatOpen(false)} />
    <div className="footer-note"><span>LEGAL FIRST-AID AI</span><span>General information · Not legal advice</span></div>
  </div>;
}
